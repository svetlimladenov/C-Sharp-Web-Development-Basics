﻿namespace SIS.Http.Enums
{
    public enum HttpRequestMethod
    {
        Get,
        Post,
        Put,
        Delete
    }
}
